


<table border=1 style='width:100%;height:100%;' >
    <tr>
        <td style='width:900px;'>
            <iframe src=maps.php width=900px height=100% frameborder=0 scrolling=no></iframe>
        </td>
        <td>
            <iframe src=maps.button.php width=90% height=100% frameborder=0 scrolling=no></iframe>
        </td>
    <tr>
</table>


